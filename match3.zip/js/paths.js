requirejs.config( {
	paths: {
	//Project Paths
		game: 'js/game',
		util: 'js/util',
		crafty: 'js/libs/crafty',
		domready: 'js/libs/ondomready',
        sift: 'js/libs/sift'
	}
} );