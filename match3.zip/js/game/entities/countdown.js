define(['crafty'], function (Crafty) {
	return {
		init : function () {

		}
	};
});