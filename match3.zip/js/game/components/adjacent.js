define(['crafty','game/game'], function (Crafty, Game) {
    return {
        init : function () {
            Crafty.c('Adjacent', {
                init: function() {
                    
                }
            });
        }
    };
});